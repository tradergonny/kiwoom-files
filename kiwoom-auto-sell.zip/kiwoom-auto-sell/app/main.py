"""
FastAPI 서버. 웹 UI + REST API 제공.
시작 시:
  - DB 초기화
  - 엔진 백그라운드 태스크 시작 (10초마다 tick)
"""
from __future__ import annotations

import logging
import asyncio
from contextlib import asynccontextmanager
from pathlib import Path
from typing import Optional

from fastapi import FastAPI, HTTPException, Request
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.templating import Jinja2Templates
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field

from . import db
from .kiwoom import KiwoomClient, KiwoomAPIError
from .engine import AutoSellEngine

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s %(levelname)s [%(name)s] %(message)s",
)
log = logging.getLogger("main")

BASE_DIR = Path(__file__).resolve().parent
templates = Jinja2Templates(directory=str(BASE_DIR / "templates"))

# --- 싱글톤 클라이언트 ---

_client: Optional[KiwoomClient] = None


def _build_client_from_db() -> Optional[KiwoomClient]:
    appkey = db.config_get("appkey")
    secretkey = db.config_get("secretkey")
    if not appkey or not secretkey:
        return None
    is_mock = db.config_get("is_mock", "1") == "1"
    return KiwoomClient(appkey, secretkey, is_mock=is_mock)


def _refresh_client():
    global _client
    _client = _build_client_from_db()


def _client_factory() -> Optional[KiwoomClient]:
    return _client


engine = AutoSellEngine(client_factory=_client_factory)


# --- 앱 lifecycle ---

@asynccontextmanager
async def lifespan(app: FastAPI):
    db.init_db()
    _refresh_client()
    await engine.start(interval_sec=10)
    log.info("서버 시작 완료")
    try:
        yield
    finally:
        await engine.stop()
        log.info("서버 종료")


app = FastAPI(title="키움 자동매도", lifespan=lifespan)

# 정적 파일
static_dir = BASE_DIR / "static"
static_dir.mkdir(exist_ok=True)
app.mount("/static", StaticFiles(directory=str(static_dir)), name="static")


# ---------- 라우트 ----------

@app.get("/", response_class=HTMLResponse)
async def index(request: Request):
    return templates.TemplateResponse("index.html", {"request": request})


# ----- 설정 -----

class ConfigIn(BaseModel):
    appkey: str = Field(..., min_length=10)
    secretkey: str = Field(..., min_length=10)
    is_mock: bool = True


@app.get("/api/config")
async def api_get_config():
    return {
        "configured": bool(db.config_get("appkey") and db.config_get("secretkey")),
        "is_mock": db.config_get("is_mock", "1") == "1",
        "appkey_masked": _mask(db.config_get("appkey", "")),
    }


@app.post("/api/config")
async def api_save_config(cfg: ConfigIn):
    db.config_set("appkey", cfg.appkey.strip())
    db.config_set("secretkey", cfg.secretkey.strip())
    db.config_set("is_mock", "1" if cfg.is_mock else "0")
    _refresh_client()
    db.log_activity("config_saved", "", f"모드={'모의' if cfg.is_mock else '실전'}")
    return {"ok": True}


@app.post("/api/toggle-mode")
async def api_toggle_mode():
    cur = db.config_get("is_mock", "1") == "1"
    new_val = "0" if cur else "1"
    db.config_set("is_mock", new_val)
    _refresh_client()
    db.log_activity("mode_toggled", "", f"모드 전환 → {'모의' if new_val == '1' else '실전'}")
    return {"is_mock": new_val == "1"}


@app.post("/api/test-connection")
async def api_test_connection():
    cli = _client_factory()
    if not cli:
        raise HTTPException(400, "API 키가 설정되지 않았습니다")
    try:
        token = await cli.get_token()
        return {"ok": True, "token_preview": token[:20] + "...",
                "host": cli.host, "mode": "모의" if cli.is_mock else "실전"}
    except KiwoomAPIError as e:
        raise HTTPException(400, f"연결 실패: {e}")


# ----- 보유종목 -----

@app.get("/api/holdings")
async def api_holdings():
    cli = _client_factory()
    if not cli:
        raise HTTPException(400, "API 키가 설정되지 않았습니다")
    try:
        return {"holdings": await cli.get_holdings()}
    except KiwoomAPIError as e:
        raise HTTPException(502, f"조회 실패: {e}")


# ----- 전략 -----

class StrategyIn(BaseModel):
    stock_code: str
    stock_name: str = ""
    strategy_type: str  # day | target | swing1 | swing2 | swing3
    holding_qty: int    # 보유 수량 (홀짝 조정 전 원본)
    params: dict = {}


@app.get("/api/strategies")
async def api_list_strategies():
    out = []
    for s in db.list_strategies():
        s["slots"] = db.get_slots(s["stock_code"])
        out.append(s)
    return {"strategies": out}


@app.post("/api/strategies")
async def api_set_strategy(s: StrategyIn):
    if s.strategy_type not in ("day", "target", "swing1", "swing2", "swing3"):
        raise HTTPException(400, "잘못된 전략 타입")
    if s.holding_qty < 4:
        raise HTTPException(400, "보유 수량은 4주 이상이어야 합니다 (4등분 필요)")

    # 홀수면 1주 제외하고 짝수화
    reserved = 1 if s.holding_qty % 2 else 0
    total = s.holding_qty - reserved
    if total < 4:
        raise HTTPException(400, "짝수화 후 수량이 4주 미만입니다")

    # 기존 전략 있으면 주문 전부 취소 후 슬롯 삭제
    existing = db.get_strategy(s.stock_code)
    if existing:
        await engine.cancel_all_for_stock(s.stock_code)
        db.delete_slots(s.stock_code)

    # 전략별 파라미터 검증
    params = dict(s.params or {})
    if s.strategy_type == "day":
        # Case B 기본값
        if "case_b_pcts" not in params:
            params["case_b_pcts"] = [4.5, 5.2, 5.5, 5.8]
    elif s.strategy_type == "target":
        tp = int(params.get("target_price", 0))
        if tp <= 0:
            raise HTTPException(400, "목표가를 입력해 주세요")
    elif s.strategy_type == "swing1":
        params.setdefault("gain_pct", 10.0)
    elif s.strategy_type == "swing2":
        tp = int(params.get("trigger_price", 0))
        if tp <= 0:
            raise HTTPException(400, "기준가를 입력해 주세요")
    elif s.strategy_type == "swing3":
        params.setdefault("drop_pct", 6.0)

    db.upsert_strategy(
        stock_code=s.stock_code,
        stock_name=s.stock_name,
        strategy_type=s.strategy_type,
        params=params,
        total_qty=total,
        reserved_qty=reserved,
    )
    db.log_activity(
        "strategy_set", s.stock_code,
        f"{s.strategy_type} 설정 (총 {s.holding_qty}주 → 대상 {total}주, 예비 {reserved}주) "
        f"params={params}"
    )
    return {"ok": True, "total_qty": total, "reserved_qty": reserved}


@app.post("/api/strategies/{stock_code}/cancel")
async def api_cancel_strategy(stock_code: str):
    existing = db.get_strategy(stock_code)
    if not existing:
        raise HTTPException(404, "없는 전략")
    n = await engine.cancel_all_for_stock(stock_code)
    db.delete_strategy(stock_code)
    db.delete_slots(stock_code)
    db.log_activity("strategy_cancelled", stock_code, f"전략 해제 및 주문 {n}건 취소")
    return {"ok": True, "cancelled_orders": n}


@app.post("/api/emergency-stop")
async def api_emergency_stop():
    cli = _client_factory()
    if not cli:
        raise HTTPException(400, "API 키가 설정되지 않았습니다")
    total = 0
    errors = []
    for s in db.list_strategies(active_only=True):
        try:
            n = await engine.cancel_all_for_stock(s["stock_code"])
            total += n
        except Exception as e:
            errors.append(f"{s['stock_code']}: {e}")
    db.log_activity("emergency_stop", "", f"응급정지 - 총 {total}건 취소, 오류 {len(errors)}건",
                    level="WARN")
    return {"ok": True, "cancelled": total, "errors": errors}


# ----- 기타 -----

@app.get("/api/logs")
async def api_logs(limit: int = 200):
    return {"logs": db.recent_logs(limit=limit)}


@app.get("/api/status")
async def api_status():
    from datetime import datetime
    from .kiwoom import KST
    now = datetime.now(KST)
    return {
        "now_kst": now.isoformat(timespec="seconds"),
        "weekday": now.weekday(),  # 0=월, 6=일
        "market_open": (now.weekday() < 5
                        and now.time().hour * 60 + now.time().minute >= 9 * 60
                        and now.time().hour * 60 + now.time().minute < 15 * 60 + 30),
        "engine_running": engine._running,
        "client_configured": _client is not None,
    }


def _mask(s: str) -> str:
    if not s:
        return ""
    if len(s) <= 8:
        return "****"
    return s[:4] + "****" + s[-4:]
