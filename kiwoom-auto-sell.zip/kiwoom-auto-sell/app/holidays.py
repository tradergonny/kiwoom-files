"""
한국 증시 휴장일.
매년 KRX가 공식 발표하는 휴장일 목록.
실제 운영 시에는 매년 1월에 한 번씩 갱신이 필요함.
출처: https://open.krx.co.kr (휴장일 캘린더)
"""
from datetime import date

# 2026년 한국 증시 휴장일 (예상 - KRX 공식 발표 기준 갱신 필요)
# 토/일은 별도 처리. 법정 공휴일 + 근로자의날 + 연말 휴장.
HOLIDAYS_2026 = {
    date(2026, 1, 1),   # 신정
    date(2026, 2, 16),  # 설날 연휴
    date(2026, 2, 17),  # 설날
    date(2026, 2, 18),  # 설날 연휴
    date(2026, 3, 1),   # 삼일절 (일요일, 대체공휴일 가능성)
    date(2026, 3, 2),   # 삼일절 대체공휴일
    date(2026, 5, 1),   # 근로자의날
    date(2026, 5, 5),   # 어린이날
    date(2026, 5, 25),  # 부처님오신날
    date(2026, 6, 3),   # 제8회 전국동시지방선거 (예상)
    date(2026, 6, 6),   # 현충일 (토요일)
    date(2026, 8, 15),  # 광복절 (토요일)
    date(2026, 9, 24),  # 추석 연휴
    date(2026, 9, 25),  # 추석
    date(2026, 9, 26),  # 추석 연휴 (토요일)
    date(2026, 10, 3),  # 개천절 (토요일)
    date(2026, 10, 5),  # 개천절 대체공휴일
    date(2026, 10, 9),  # 한글날
    date(2026, 12, 25), # 성탄절
    date(2026, 12, 31), # 연말 폐장일
}

# 2027년 (대략 추정값, 나중에 갱신 필요)
HOLIDAYS_2027 = {
    date(2027, 1, 1),
    date(2027, 2, 5),   # 설날 연휴
    date(2027, 2, 6),   # 설날
    date(2027, 2, 7),   # 일요일
    date(2027, 2, 8),   # 대체공휴일
    date(2027, 3, 1),
    date(2027, 5, 1),
    date(2027, 5, 5),
    date(2027, 5, 13),  # 부처님오신날
    date(2027, 6, 6),
    date(2027, 8, 15),
    date(2027, 9, 14),  # 추석
    date(2027, 9, 15),
    date(2027, 9, 16),
    date(2027, 10, 3),
    date(2027, 10, 9),
    date(2027, 12, 25),
    date(2027, 12, 31),
}

ALL_HOLIDAYS = HOLIDAYS_2026 | HOLIDAYS_2027


def is_market_holiday(d: date) -> bool:
    """주어진 날짜가 한국 증시 휴장일이면 True."""
    # 토/일 주말
    if d.weekday() >= 5:
        return True
    # 공휴일 목록
    return d in ALL_HOLIDAYS


def next_market_day(d: date) -> date:
    """주어진 날짜 다음 개장일 반환."""
    from datetime import timedelta
    nxt = d + timedelta(days=1)
    while is_market_holiday(nxt):
        nxt += timedelta(days=1)
    return nxt
